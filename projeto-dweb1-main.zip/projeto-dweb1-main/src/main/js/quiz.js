//vetor contendo as perguntas
const perguntas = [
  {
    pergunta: "O que mais te interessa em um lugar?",
    opcoes: [
      { texto: "A história e pessoas que estão por trás", perfil: "A" }, // história, arte
      { texto: "Experiência do momento e sensações", perfil: "B" }, // pontos, gastronomia
    ],
  },
  {
    pergunta: "Você se considera uma pessoa mais...",
    opcoes: [
      { texto: "Tradicional e que prefere coisas com renome", perfil: "A" }, // história, pontos
      { texto: "Moderna e disposta a conhecer coisas novas", perfil: "B" }, // arte, gastronomia
    ],
  },
  {
    pergunta: "Qual ritmo você prefere?",
    opcoes: [
      { texto: "Muita coisa em pouco tempo", perfil: "A" },
      { texto: "Calmo e com pausas", perfil: "B" },
    ],
  },
  {
    pergunta: "No fim da semana, você prefere...",
    opcoes: [
      { texto: "Sair para um lugar agitado", perfil: "A" },
      { texto: "Repôr as energias em um lugar tranquilo", perfil: "B" },
    ],
  },
  {
    pergunta: "Diante de algo novo, você...",
    opcoes: [
      { texto: "Quero experimentar", perfil: "A" },
      { texto: "Quero entender", perfil: "B" },
    ],
  },
  {
    pergunta: "Que tipo de ambiente você prefere?",
    opcoes: [
      { texto: "Cidade movimentada", perfil: "A" },
      { texto: "Natureza e paisagens", perfil: "B" },
    ],
  },
];

// matriz com os ids de cada tour
const matrizResultados = [
  ["Italiana", "Antiga", "Assombrada"], // história e cultura
  ["Arquitetonica", "Artistica", "Urbana"], // arte e arquitetura
  ["Verde", "Independente", "Alto"], // pontos turísticos
  ["Cafe", "Oriental", "Sabores"], // gastronomia
];

// objeto que armazena dados de cada tour

const tours = {
  Italiana: {
    nome: "Sampa Italiana",
    descricao: "Bixiga e suas cantinas, da Estação Brigadeiro à Escadaria do Bixiga.",
    imagem: "img/SampaItaliana.png",
  },
  Antiga: {
    nome: "Sampa Antiga",
    descricao: "Praça da República, Theatro Municipal, Pateo do Collegio e Catedral da Sé.",
    imagem: "img/SampaAntiga.png",
  },
  Assombrada: {
    nome: "Sampa Assombrada",
    descricao: "Lendas urbanas da Estação São Bento ao Cemitério da Consolação.",
    imagem: "img/SampaAssombrada.png",
  },
  Arquitetonica: {
    nome: "Sampa Arquitetônica",
    descricao: "Do MASP à Casa das Rosas pela Avenida Paulista.",
    imagem: "img/SampaArquitetonica.png",
  },
  Artistica: {
    nome: "Sampa Artística",
    descricao: "Museu da Língua Portuguesa, Pinacoteca e MASP, com trecho de van.",
    imagem: "img/SampaArtistica.png",
  },
  Urbana: {
    nome: "Sampa Urbana",
    descricao: "Arte de rua e grafites no Beco do Batman, na Vila Madalena.",
    imagem: "img/SampaUrbana.png",
  },
  Verde: {
    nome: "Sampa Verde",
    descricao: "Parque Ibirapuera: lago, Marquise, Oca e áreas verdes.",
    imagem: "img/SampaVerde.png",
  },
  Independente: {
    nome: "Sampa Independente",
    descricao: "Parque da Independência e arredores do Museu do Ipiranga.",
    imagem: "img/SampaIndependente.png",
  },
  Alto: {
    nome: "Sampa do Alto",
    descricao: "Vistas do centro: Largo São Bento, Anhangabaú e Farol Santander.",
    imagem: "img/SampaAlto.png",
  },
  Cafe: {
    nome: "Sampa Café",
    descricao: "Cafeterias da Vila Madalena e de Pinheiros.",
    imagem: "img/SampaCafe.png",
  },
  Oriental: {
    nome: "Sampa Oriental Gastronômica",
    descricao: "Sabores japoneses e asiáticos pela Liberdade.",
    imagem: "img/SampaOrientalGastronomica.png",
  },
  Sabores: {
    nome: "Sampa de Sabores",
    descricao: "Mercado Municipal: bancas, queijos, temperos e o sanduíche de mortadela.",
    imagem: "img/SampaSabores.png",
  },
};

const categoriaNomes = ["História e Cultura", "Arte e Arquitetura", "Pontos Turísticos", "Gastronomia"];

// o  método "querySelector" seleciona os elementos do DOM que correspondem ao seletor CSS fornecido
const elementoPergunta = document.querySelector(".pergunta");
const botoesOpcao = document.querySelector(".opcoes"); // é o fieldset que contém os botões de opção
const botaoProximo = document.querySelector(".botao-proximo");
const progresso = document.querySelector(".progresso");
const resultadoQuiz = document.querySelector(".resultado-quiz"); // section
const resultadoImagem = document.querySelector(".resultado-imagem");
const resultadoCategoria = document.querySelector(".resultado-categoria"); 
const resultadoNome = document.querySelector(".resultado-nome");
const resultadoDesc = document.querySelector(".resultado-descricao");

let perguntaAtualIndice = 0;
let respostas = []; // vetor que vai armazenar as respostas do usuário

function comecarQuiz() {
  perguntaAtualIndice = 0; // reincia o índice da pergunta
  respostas = []; // esvazia o vetor que guarda as respostas
  mostrarPergunta();

}

function mostrarPergunta() {
  resetarEstado(); // esconde os botões originais do HTML

  let perguntaAtual = perguntas[perguntaAtualIndice]; // a pergunta atual é um vetor de perguntas de 0 a 5
  let perguntaNum = perguntaAtualIndice + 1;

  progresso.innerHTML = `${perguntaNum}/6`; // atualiza o progresso
  // muda diretamente a pergunta
  elementoPergunta.innerHTML = perguntaNum + ". " + perguntaAtual.pergunta; // associa o número com a pergunta
  // para cada opção da pergunta atual (que é um elemento de um vetor), executa uma função...
  // "opcao" é o parâmetro que irá receber um valor a cada iteração, sendo um vetor contendo texto e perfil

  perguntaAtual.opcoes.forEach((opcao) => {
    const lbopcao = document.createElement("label"); // cria um elemento do tipo botão no documento HTML
    lbopcao.classList.add("opcao"); // adiciona o botão à classe "opcao"
    const botao = document.createElement("input"); // cria um elemento do tipo input no documento HTML
    botao.type = "radio";
    botao.name = "opcao";
    botao.value = opcao.perfil;

    lbopcao.appendChild(botao); // adiciona o botão ao label
    lbopcao.appendChild(document.createTextNode(opcao.texto));
    botoesOpcao.appendChild(lbopcao); // adiciona o label à lista de opções

    botao.addEventListener("change", () => {
      selecionaOpcao(); // chama a função quando o botão é clicado, passando a opcao escolhida
    });
  });
}

function resetarEstado() { // esconde o resultado e os botões
  botaoProximo.style.display = "none"; // esconde o botão de próxima pergunta
  resultadoQuiz.style.display = "none";
  botoesOpcao.innerHTML = ""; // esconde os botões de opção
}

function selecionaOpcao() {
  const botaoSelecionado = document.querySelector(
    'input[name="opcao"]:checked',
  );
  respostas[perguntaAtualIndice] = botaoSelecionado.value; // armazena a resposta do usuário no vetor
  botaoProximo.style.display = "block"; // mostra o botão de próxima pergunta
}

function calcularResultado(respostas) {
  // if/else compacto
  categoria = (respostas[0] === "A" ? 0 : 2) + (respostas[1] === "A" ? 0 : 1); // divide nas 4 categorias
  contagem = respostas.slice(2).filter((r) => r === "A").length; // divide as respostas e conta os A
  faixa = contagem <= 1 ? 0 : contagem === 2 ? 1 : 2; // atribui faixa 1, 2 ou 3
  return matrizResultados[categoria][faixa];
}

function mostrarResultado() {
  resetarEstado(); // esconde o bloco da pergunta e opções
  const tourFinal = calcularResultado(respostas); // resulta em um dos resultados na MATRIZ, que tem um correspondente no objeto de dados tours
  elementoPergunta.innerHTML = "A SUA TOUR IDEAL É...";
  resultadoQuiz.style.display = "block"; // resultado aparece
  resultadoCategoria.textContent = categoriaNomes[categoria];
  resultadoNome.textContent = tours[tourFinal].nome;
  resultadoDesc.textContent = tours[tourFinal].descricao;
  resultadoImagem.src=tours[tourFinal].imagem;
  resultadoImagem.alt=tours[tourFinal].nome;
}

// evento de clique no botão de próxima pergunta:
botaoProximo.addEventListener("click", () => {
    perguntaAtualIndice++; // avança pra próxima pergunta
    if (perguntaAtualIndice < perguntas.length) {
      mostrarPergunta();
    } else {
      mostrarResultado();
    }
});

comecarQuiz();